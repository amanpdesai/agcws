#!/usr/bin/env bash
set -euo pipefail

repo_root=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
cd "$repo_root"
source scripts/load_env.sh
if [[ $# -lt 1 || $# -gt 2 ]]; then
  echo "usage: $0 WAVEFORM.vcd [OUTPUT_DIR]" >&2
  exit 2
fi
waveform=$1
out_dir=${2:-out/aes-cross-pdk}
sky_lib=${AGCWS_LIBERTY:-third_party/liberty/sky130hd/sky130_fd_sc_hd__tt_025C_1v80.lib}
nangate_lib=${AGCWS_LIBERTY_NANGATE45:-third_party/liberty/nangate45/Nangate45_typ.lib}
mkdir -p "$out_dir"

if [[ -z "${AGCWS_SLANG_PLUGIN:-}" || ! -f "${AGCWS_SLANG_PLUGIN}" ]]; then
  cat >&2 <<'EOF'
cross-PDK AES synthesis requires a Yosys Slang plugin.
Set AGCWS_SLANG_PLUGIN to the checked plugin path (Docker supplies it), then
rerun this command. The compatibility frontend cannot parse the OpenTitan AES
source set reliably.
EOF
  exit 2
fi

for name in sky130hd nangate45; do
  if [[ "$name" == sky130hd ]]; then lib=$sky_lib; else lib=$nangate_lib; fi
  AGCWS_LIBERTY="$lib" AGCWS_SLANG_PLUGIN="${AGCWS_SLANG_PLUGIN:-}" \
    bash scripts/synthesize_aes_core.sh "$out_dir/$name-synthesis"
  bash scripts/run_opensta_aes.sh "$out_dir/$name-synthesis" "$waveform" \
    "$out_dir/$name-power" "$lib"
done

python3 - "$out_dir/comparison.json" "$out_dir" "$waveform" "$sky_lib" "$nangate_lib" <<'PY'
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

output, root, waveform, sky_lib, nangate_lib = sys.argv[1:]
waveform_path = Path(waveform)
if not waveform_path.is_file():
    raise FileNotFoundError(f"waveform is not a file: {waveform_path}")
def power(name):
    for line in (Path(root) / f"{name}-power/power.rpt").read_text().splitlines():
        fields = line.split()
        if fields and fields[0] == "Total" and len(fields) >= 5:
            return float(fields[4])
    raise ValueError(f"no total power in {name} report")
def annotation(name):
    text = (Path(root) / f"{name}-power/power.rpt").read_text()
    annotated = next((int(line.split()[1]) for line in text.splitlines()
                      if line.startswith("Annotated ") and "pin activities" in line), None)
    unannotated = next((int(line.split()[1]) for line in text.splitlines()
                        if line.strip().startswith("unannotated ")), None)
    if annotated is None or unannotated is None:
        raise ValueError(f"no parseable annotation summary in {name} report")
    total = annotated + unannotated
    return {"annotated_pins": annotated, "unannotated_pins": unannotated,
            "annotation_fraction": annotated / total if total else 0.0}
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def tool_version(command, *args):
    try:
        return subprocess.check_output([command, *args], text=True,
                                       stderr=subprocess.STDOUT).splitlines()[0]
    except (OSError, subprocess.CalledProcessError) as exc:
        return f"unavailable: {exc}"

Path(output).write_text(json.dumps({
    "waveform": {"path": waveform_path.name, "sha256": sha(waveform_path)},
    "power_metric": "opensta_total_power_w",
    "tools": {
        "yosys": tool_version(os.environ.get("AGCWS_YOSYS", "yosys"), "-V"),
        "opensta": tool_version(os.environ.get("AGCWS_OPENSTA", "sta"), "-version"),
        "slang_plugin": {
            "path": os.environ.get("AGCWS_SLANG_PLUGIN", ""),
            "sha256": sha(os.environ["AGCWS_SLANG_PLUGIN"])
            if os.environ.get("AGCWS_SLANG_PLUGIN") else None,
        },
    },
    "pdks": {
        "sky130hd": {"liberty": sky_lib, "liberty_sha256": sha(sky_lib),
                     "total_power_w": power("sky130hd"), "annotation": annotation("sky130hd")},
        "nangate45": {"liberty": nangate_lib, "liberty_sha256": sha(nangate_lib),
                       "total_power_w": power("nangate45"), "annotation": annotation("nangate45")},
    },
}, indent=2) + "\n")
PY
echo "CROSS_PDK_DONE comparison=$out_dir/comparison.json"
