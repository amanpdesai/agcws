# Results status

Latest engineering milestone: [temporal scaling qualification](TEMPORAL_SCALING_V1_RESULTS.md)
is complete, with twelve witness attempts, 72 CPU search slots and zero model
calls. New phase controls are operational; synthetic requests remain unqualified.
This is not a new agent-comparison result or fresh-seed confirmation.

Latest completed [closed-loop depth results](IBEX_DEPTH_V1_RESULTS.md): 48 cells,
6,144 slots, all 16/64/128 prefixes. Primary 128-slot mean AUC is 6.4399 for Pro,
24.6608 for Flash, 26.3595 for random and 35.0842 for coverage; solves are
12/12, 7/12, 3/12 and 3/12. This is development-only, not held-out confirmation
or gate-power superiority. Five charged API failures have unknown usage.

Latest capability evidence: [model × reasoning probe](IBEX_CAPABILITY_V1_RESULTS.md),
72 fixed-context cells / 144 slots, complete. Pro-4096 has the largest mean
next-batch gain (0.14234 versus random 0.02674), with four newly solved contexts
and 24/24 valid proposals. This is conditional development evidence, not AUC,
held-out inference or a replacement for the full-search findings below.

Latest programmable-Ibex development evidence:
[v4 grounded temporal study](IBEX_TEMPORAL_V4_RESULTS.md), complete at 48 cells
and 768 slots. Random AUC is 4.831839, base agent 4.990451, coverage 5.123888,
grounded agent 5.234116. The clearer response contract improves interface readiness,
but execution diagnostics plus a prediction/outcome notebook do not improve
temporal search. All policies solve only the near-flat target. The full compact
archive and all 48 finalist profiles are tracked under
`results/ibex_temporal_v4_development/`. This is development, not held-out or
gate-power superiority.

Previous programmable-Ibex development evidence:
[v3 context/correction ablation](IBEX_TEMPORAL_V3_RESULTS.md), complete at 72 cells
and 1,152 slots. Base-agent mean AUC is 4.566393 versus random 4.831839; added
context/correction does not improve the base mean. All solves are on the near-flat
target. This is observed development data, not a held-out win or a power claim.
The complete compact archive and all finalist profiles are tracked under
`results/ibex_temporal_v3_development/`.

This file retains historical infrastructure and pilot observations. The completed
two-design scalar held-out study is reported in [SEMANTIC_RESULTS.md](SEMANTIC_RESULTS.md).
The completed temporal study is reported in [STRUCTURAL_RESULTS.md](STRUCTURAL_RESULTS.md),
with its development/freeze protocol in [STRUCTURAL_TEMPORAL_PLAN.md](STRUCTURAL_TEMPORAL_PLAN.md).
These do not constitute the entire original three-design factorial study.

The temporal panel passed independent audit: 160 cells / 5120 slots, two designs,
two reference profiles, four policies and ten fresh seeds. Random has the lowest
mean AUC on both designs; the AES agent is worse than random under the corrected
test (Holm p = 0.03125). No agent/hybrid superiority is supported. All 16 selected
finalists pass matched-window, reference-checked GLS; annotation is 90247/90247
pins for unmasked AES and 36292/36296 for DMA. This validates the replay path,
not temporal gate-power targeting or general proxy-to-power agreement.

The older proxy-to-gate correlations below are superseded, not current findings:
the legacy GLS driver aggregated pacing and used a masked two-share netlist,
whereas the current RTL transaction study uses unmasked, one-share LUT AES.
Matching a clock count alone does not repair that configuration/stimulus mismatch.
The new matched smoke evidence is in `results/aes_matched_gls_smoke_v1/` and
`results/dma_matched_gls_smoke_v1/`; it does not itself establish proxy correlation.

## Verified infrastructure

### Oracle responsiveness finding

A clean 20-workload AES calibration after widening the generator produced
20/20 valid workloads and an RTL activity range of 14.37--130.21 transitions
per clock edge (806% relative spread). OpenSTA still annotated only 203 of
154,059 pins (0.132%), yielding a total-power range of only 0.050% of its
minimum. This isolates the current bottleneck to RTL-waveform-to-netlist
annotation. These reports are retained as a negative methodological result,
not as a workload-sensitive gate-level power claim.

### Gate-level simulation status

The repository now includes a flat-port AES GLS harness and a model-explicit
runner. The available Sky130 functional and primitive cell models were found,
and Icarus now compiles and runs the mapped AES netlist to completion after
defining the model's empty `UNIT_DELAY` macro. A first direct gate-level VCD
annotated 154,059/154,059 pins and produced OpenSTA total power
`0.02861616946757 W`. The flat harness includes a 2,000-cycle handshake
assertion to classify deadlocks without imposing a wall-clock experiment cap.
Verilator still hits an internal code-generation failure on this model
closure, so the reproducible GLS runner uses Icarus for this Sky130 view.

The analogous AXI GLS runner compiles the mapped DMA netlist with Sky130
functional cell models and completes the existing coupled cocotb protocol
harness (8 transfers in the probe workload). A second `memory_map` pass after
flattening removes residual unpacked FIFO arrays from the emitted Verilog, so
the waveform is now OpenSTA-readable. The probe reports `0.02201835066080 W`
with 36,292 annotated pins and 4 unannotated pins. This is a gate-level probe,
not yet a comparative policy result.

- `make verify`: 209 tests passed, one skipped; Ruff clean.
- `make research-smoke`: passed.
- `make container-smoke`: passed, including FuseSoC/Ibex source preparation
  and deterministic workload compilation.
- Containerized `make verify-ibex` now passes with a generated 10,000-instruction
  floor-compliant workload: compilation, simple-system simulation, waveform/
  counter artifact creation, and three-input provenance verification all
  succeed. This closes the Ibex RTL simulation/activity artifact boundary, not
  the separate mapped-netlist/OpenSTA boundary.
- A fresh single-container AES run using the Docker Slang frontend completed
  synthesis and OpenSTA evaluation: 38 useful blocks, synthesis-weighted total
  power `0.02159873023629 W`, 608 clock edges, and per-cycle/window activity
  artifacts. `verify_artifact` passed. Annotation was sparse (203 annotated
  versus 153,020 unannotated instances), so this is reproducibility and
  relative-search evidence, not signoff-accuracy power.
- A fresh single-container AXI-DMA run completed synthesis, coupled
  source-to-destination simulation/activity generation, OpenSTA, and generic
  artifact verification (`valid=true`, `inputs_checked=3`). The result carries
  the explicit 4,096-byte useful-work value and hashes for its waveform,
  synthesis manifest, and Liberty; it is an end-to-end pipeline result, not a
  standalone comparative claim.
- Both checked-in Liberty files contain `internal_power`, rise/fall power,
  leakage, capacitance, and clock-gating characterization.
- The AES Sky130 mapped netlist coverage check matches all 43,619 cell
  instances across 72 distinct cell types to the Liberty (`instance_coverage`
  = 1.0); reproduce with `make check-liberty-coverage`.
- AES cross-PDK corpus: the archived 10-workload corpus at
  `out/aes-pdk-rank-20260831/corpus` validates against its paired Sky130 and
  Nangate45 report roots with Spearman ρ=`0.9999999999999998` (10 shared
workloads); see `out/aes-pdk-rank-20260831/corpus-validation.json`.
- The archived temporal cross-PDK diagnostic reports Spearman ρ≈`-1.0` across
  four shared schedules (`out/aes-temporal-cross-pdk.json`), indicating a rank
  inversion rather than agreement. It is excluded from validation claims until
  the temporal workload/report pairing is independently reconciled. The paired
  means are Sky130: `low_high_low=0.01852035`, `high_low_high=0.01848644`,
  `burst=0.01915642`, `ramp=0.01844827`; Nangate45:
  `low_high_low=0.00504285`, `high_low_high=0.00505190`,
  `burst=0.00499004`, `ramp=0.00506829`. The inversion is therefore a
  PDK-dependent temporal diagnostic, not evidence of cross-PDK agreement.
- A fresh containerized AES cross-PDK run also completes both Sky130 and
  Nangate45 synthesis/OpenSTA passes, with waveform and Liberty hashes recorded
  in `out/aes-cross-pdk/comparison.json`. Its single-workload annotation is
  sparse (0.132% Sky130, 0.136% Nangate45), so it is provenance evidence rather
  than a broad cross-PDK power claim.
- In the production container, the core-only Slang frontend probe succeeds
  with `IBEX_TOP=ibex_core` and 96 elaborated sources. A subsequent Sky130
  mapping attempt reaches the synthesis flow but did not complete in the
  observed run; a Nangate45 attempt likewise did not complete. The probe now
  runs without an application timeout, so these are unfinished runs rather
  than timeout-classified results. No mapped netlist or Ibex power result is
  claimed; manifests retain source and Liberty hashes for reproduction.
- `make vertex-preflight` passes with project `agcws-507604`, model
  `gemini-2.5-flash`, and the frozen prompt hash. A one-slot AES scalar Vertex
  smoke produced a valid workload and reached the activity evaluator, recording
  450 input tokens and 136 output tokens. An initial eight-slot call also
  confirmed malformed batches consume all requested proposal slots. This is a
  plumbing smoke, not comparative evidence.

After adding generated design summaries, rendered protocol constraints, compact
history, and the explicit AES operation schema, a one-slot Vertex AES scalar
smoke produced a valid workload and completed activity evaluation. The call
recorded 557 input tokens, 189 output tokens, model `gemini-2.5-flash`, and the
frozen prompt hash. The parser also accepts a singleton JSON workload when the
requested batch size is one.
- `make analyze-baseline BASELINE_DIR=out/aes-baseline-matrix-complete
  ANALYSIS_DIR=out/final-analysis` completes successfully, producing 25
  policy-target groups (125 run summaries across five policies and five scalar
  targets) and a reproducible convergence figure. This verifies the analysis
  tooling; it is not the undeclared multi-design final study.

## Preliminary AXI-DMA activity calibration

The corrected coupled-harness calibration combines three random seeds and is
stored at `out/axi-dma-calibration-corrected-3seed.json`: 48 valid proposals,
16 distinct activity values, and an observed activity range of
`19.67403066–19.80286242` total transitions per clock edge. Workloads are
non-overlapping, in-bounds, and satisfy the 4,096-byte useful-work floor.
These are activity-proxy bounds, not synthesis-level power bounds; they are
not yet used to claim a completed DMA comparative study.

The pacing-enabled generator was calibrated separately with 20 fresh random
workloads. All 20 passed validation and produced 20 distinct activity values;
the range widened to `12.38400853–19.90410309` transitions per clock edge.
This is the corrected envelope for future DMA activity searches. It varies
back-to-back, lightly gapped, bursty, and sparse descriptor schedules while
retaining the 4,096-byte floor and AXI 4-KiB legality rules.

A direct AES GLS runtime probe on the largest fresh calibration workload
(238 blocks) exceeded 13 minutes and generated a 220 MiB VCD before being
stopped. This confirms that GLS/OpenSTA belongs in the finalist tier rather
than the inner loop; a complete 20-workload proxy-to-gate correlation must be
run as a separately budgeted validation experiment.

The one-block RTL activity smoke measured 3.42 s wall time including the
initial Verilator build and produced a 19.5 MiB VCD. The existing one-block
GLS probe completed, but the full calibration DSL is not replayed by that
harness: data patterns and inter-block timing are not equivalent. Therefore no
proxy-to-gate correlation is reported yet; GLS/OpenSTA remains finalist-only
validation rather than an inner-loop evaluator.

The GLS harness now accepts the workload's block count, pattern, key length,
direction, and aggregate pacing. A 221-block replay compiled and launched with
those controls, reached 307 MiB of VCD after about five minutes, and was
stopped manually. This was aggregate-control replay, not exact transaction replay:
operation ordering and the current unmasked configuration were not preserved.
Its runtime is a historical observation for that older configuration, not a
validated estimate for the new matched transaction harness.

The earlier one-block bounded run reported ρ=`0.0968280607`; it is superseded
because constant projection removed the corpus's block-count variance. The
correlation tool now supports the preregistered ladder of 1, 2, 4, 8, 16, and
32 blocks and parses OpenSTA dynamic power as internal plus switching power,
excluding leakage. The full ladder run is pending; no constant-projection
correlation is used as evidence.

The corrected recomputation uses each GLS VCD's own clock span, but retains the
declared rate-vs-rate comparison: RTL transitions per cycle versus GLS dynamic
power. Over the 34 completed rows, pooled ρ=`-0.7169173149` and block-controlled
partial Spearman ρ=`-0.1168103321`. Per-rung correlations are `-0.0990` (1/2
blocks), `0.2970` (4/8), and `0.2962` (16/32). These are partial diagnostics,
not a final 20-workload result. The configuration/stimulus mismatch identified
above additionally disqualifies them as evidence for or against the current
activity proxy, independently of incomplete sampling or window effects.

An initial ladder attempt was stopped after 34 completed, but not valid matched-tier, rows: it had
run for about 2h45 locally and was still processing the 16-block rung. Its
partial pooled diagnostic was ρ=`-0.7169`, but it is not a result because the
ladder was incomplete. This invalidates the earlier estimate that 32-block GLS
would fit comfortably under a minute and motivates trace reuse or an explicitly
bounded validation budget before final correlation claims.

A calibrated five-policy smoke matrix at 20 proposal slots is stored at
`out/axi-dma-matrix-calibrated-seed0/`, with an aggregate at
`out/axi-dma-matrix-calibrated-seed0-aggregate.json`. All 100 proposal slots
ran validly through the coupled Docker oracle; no policy reached the primary
0.05 tolerance within this short smoke budget. This is orchestration evidence,
not a comparative result.

A second seed has since completed the same matrix. The two-seed aggregate is
`out/axi-dma-matrix-calibrated-2seed-aggregate.json`: 5 policies × 20 slots ×
2 seeds, 200/200 valid simulations, and zero solves. The preregistered 200-slot
DMA comparison remains outstanding; these short runs only validate stability
of the calibrated orchestration.

The first full-budget calibrated DMA run is stored at
`out/axi-dma-matrix-calibrated-200-seed0/`, with aggregate
`out/axi-dma-matrix-calibrated-200-seed0-aggregate.json`. At 200 proposals,
random reached tolerance at evaluation 51 and offline-hybrid at 101; mutation,
evolutionary, and one-shot-agent were unsolved. All five arms completed 200
valid simulations with no validity-stage failures. This is one seed on one
activity oracle and is preliminary evidence, not a general policy ranking.

A five-seed full-budget matrix is now complete across the five policies, with
200 proposal slots per policy and seed. Paired inference is recorded at
`out/axi-dma-inference-5seed.json`; the panel remains small and underpowered for
definitive policy claims, and the result is still limited to the AXI DMA
activity oracle rather than the full multi-design study.

Held-out profile-arm Docker smokes also complete end to end. The temporal run
(`out/aes-temporal-heldout-20260901/`) used an achieved target manifest with 8
coarse windows and produced 8/8 valid simulations with 2,444 per-cycle samples;
the compositional run (`out/aes-compositional-heldout-20260901/`) likewise
produced 8/8 valid simulations against an achieved region-share target. Neither
short smoke solved its target. These validate profile plumbing and provenance,
not the full G4 comparison.

A larger one-seed profile run is also complete. The temporal arm at 32
proposals (`out/aes-temporal-heldout-20260901-seed1/`) produced 32/32 valid
simulations, retained 2,425 per-cycle samples per candidate, and reached its
achieved target within budget. The compositional arm
(`out/aes-compositional-heldout-20260901-seed1/`) produced 32/32 valid
simulations with 672 per-cycle samples per candidate but did not reach its
target. This is a G4 plumbing/milestone result for one target and one seed,
not a comparative profile conclusion.

Machine-readable aggregates for this snapshot are
`out/aes-temporal-pilot-aggregate.json` and
`out/aes-compositional-pilot-aggregate.json`. The aggregation command recovers
target identity from archived `target.json` files, preserving four temporal
target groups and five compositional target groups with three-run denominators
and deterministic bootstrap summaries.

The profile smoke was expanded to three seeds at 32 proposals per seed. Across
the temporal arm, 96/96 simulations were valid and 2/3 seeds solved the same
held-out achieved target. Across the compositional arm, 96/96 were valid and
0/3 seeds solved its held-out region-share target. Every run retained per-cycle
activity and target provenance. This remains one target per class and is not a
general profile-method conclusion.
The original temporal manifest contained one target, but the source corpus
contains four achieved schedules. A deterministic two-target manifest is now
recorded at `out/aes-temporal-targets-2.json`; the newly executed `burst` target
covered three seeds (96/96 valid simulations), with aggregate
`out/aes-temporal-burst-3seed-aggregate.json`. The reported profile evidence
therefore spans two achieved temporal schedules, while the compositional snapshot
now covers targets 0 and 1. Target 1 has aggregate
`out/aes-compositional-target1-3seed-aggregate.json` with 96/96 valid
simulations and 0/3 solves. The compositional target set still has additional
unrun achieved targets.

An older compositional pilot record referenced targets 2, 3, and 4 from a
superseded corpus. Those artifacts are not the current policy matrix and are
not used for its claims. The current machine-readable manifest contains three
targets, all of which are covered by the policy matrix below. The repeated AUC
values across these nearby region-share goals indicate that the current
32-proposal activity budget is not separating them; they are not evidence of
target generality.

The remaining achieved temporal schedules are now covered as well: `high_low_high`
and `ramp` each ran for three seeds at 32 proposals, with 96/96 valid
simulations and 0/3 solves for each. Their aggregates are
`out/aes-temporal-target2-3seed-aggregate.json` and
`out/aes-temporal-target3-3seed-aggregate.json`. The temporal pilot therefore
covers all four achieved schedules, 384 valid simulations total, and 2/12
seed-target solves across the two schedules already reported plus these two.

The profile-policy seam was then exercised on all four achieved temporal targets:
`out/aes-temporal-policy-matrix-20260901-v2-aggregate.json` contains five
distinct policies, three seeds per target-policy cell, and 32 proposal slots per
run. The matrix has 20 target-policy groups and 1,904 valid trials out of 1,920
proposal slots; it is a preliminary four-target activity comparison, not the
full preregistered profile factorial or a gate-level power result.
Paired policy inference for this matrix is recorded in
`out/aes-temporal-policy-inference-32.json`; each comparison has three matched
seeds per achieved target and Holm-adjusted p-values. The panel is too small for
definitive policy claims.
The corresponding convergence figures are
`out/figures/temporal-policy-convergence.png` and
`out/figures/compositional-policy-convergence.png`.

The corresponding compositional comparison is archived at
`out/aes-compositional-policy-matrix-20260901-v2-aggregate.json`: three achieved
region-share targets, five policies, three seeds, and 32 proposal slots per
run. It contains 15 target-policy groups and 1,434 valid trials out of 1,440
proposal slots. This is preliminary AES activity-oracle evidence, not a full
multi-design or gate-level result. The manifest contains three targets; older
notes referring to five targets describe a superseded corpus and are not part
of this matrix.

The rerun at the preregistered profile budget is archived at
`out/aes-compositional-policy-matrix-20260901-300-aggregate.json`: the same
three achieved region-share targets, five policies, three seeds, and 300
proposal slots per cell. It contains 15 target-policy groups and 13,410 valid
trials out of 13,500 proposal slots, with no profile-audit errors. This remains
preliminary AES activity-oracle evidence, not a multi-design or gate-level
result; the corresponding figure is
`out/figures/compositional-policy-convergence-300.png`.
Paired policy inference for this matrix is recorded in
`out/aes-compositional-policy-inference-300.json`; each comparison has three
matched seeds per achieved target and Holm-adjusted p-values. The panel is too
small for definitive policy claims.

The five-seed full-budget aggregate is
`out/axi-dma-matrix-calibrated-200-5seed-aggregate.json`, with paired inference
at `out/axi-dma-inference-5seed.json`: 5 policies × 200 proposals × 5 seeds.
This panel is still small and underpowered for definitive policy claims; use the
machine-readable inference for exact paired statistics.
The corresponding multi-root convergence figure is
`out/axi-dma-analysis-5seed/convergence.png`, generated from the five seed
roots with `analysis/plot_search_curves.py`.

## Preliminary AES scalar study

The verified AES scalar aggregate combines the original corpus with seeds 5
through 9 and is stored at `out/aes-analysis-10seed/aggregate.json`. It
contains five policies, five scalar targets, and exactly ten seeds per
policy/target cell (250 run summaries total). The corresponding convergence
figure is `out/aes-analysis-10seed/convergence.png`.

In this corpus, all policies solve the high target (`q=0.90`) at least once;
the recorded solve rates are random `1.0`, mutation `1.0`, evolutionary `1.0`,
hybrid `1.0`, and one-shot agent `0.8`. The lower targets have no recorded
solves in these runs. These are descriptive preliminary results, not a claim
that one method is superior: the corpus is AES-only, does not include the
other designs, and does not include Vertex-backed agent trials.

## Known limitations

## Fresh policy-independence smoke

On 2026-09-03, two-seed AES activity smokes were rerun after correcting policy
identity recording and the offline-agent fallback. The five declared arms
(random, mutation, evolutionary, offline-agent, and one-shot-agent) now appear
under distinct policy labels and produce distinct proposal streams. The
two-seed inference artifact contains paired comparisons for all non-random
arms; its p-values are descriptive because the smoke budget is only two
evaluations per seed and is not a preregistered final study.

The same rerun was completed for AXI DMA on 2026-09-03 with two seeds and 20
proposal slots per arm. All six arms completed: random, mutation, evolutionary,
offline-agent, one-shot-agent, and offline-hybrid. The aggregate contains paired
comparisons for each non-random arm; results are integration evidence only and
are not used as final statistical claims.

The fresh larger activity rerun also covered AES and AXI DMA with two new seeds
and 20 proposal slots per arm. The combined inference artifact contains four
paired design/seed instances for each policy shared by both designs, and two
for the AXI-only hybrid arm. These runs remain descriptive smoke evidence, not
the preregistered 5–10-seed final analysis.

- Ibex core elaboration, RTL/source closure, and standalone-core mapping are
  reproducible; simple-system wrapper mapping and Ibex gate-level power
  integration remain unsupported.
- DMA finalist OpenSTA reports have sparse activity annotation (about 1.31%
  for Sky130 and 0.77% for Nangate45 in the recorded run); they are retained
  as diagnostic evidence.
- Vertex credentials, exact model availability, and billing configuration
  are external prerequisites. No cloud-agent performance claim is made until
  `make vertex-preflight` passes and a real run records model and cost
  provenance.

The final report must replace this preliminary section only after the full
factorial run, statistical tests, finalist validation, and provenance audit
are complete.

## Memory-aware synthesis evidence

## Ibex core synthesis re-check

On 2026-09-01, a fresh Docker run of `make synthesize-ibex-core
IBEX_TOP=ibex_core` completed successfully after restoring portable defaults for
the optional FuseSoC and RISC-V tool variables. FuseSoC resolved 96 source files
and the Slang/Yosys mapping command returned zero. The earlier failure was not a
timeout: an empty exported `AGCWS_FUSESOC` value bypassed the resolver fallback.
The mapped core is still not a complete Ibex workload power pipeline; wrapper
closure and memory-compatible gate-level evaluation remain separate limitations.

## Ibex runtime activity evidence

On 2026-09-01, `make verify-ibex` completed in the verification container on a
fresh artifact root. The run compiled the generated RV32IM workload, executed
the FuseSoC simple-system simulator, converted its FST to a 19.2 MB VCD, and
produced a verified `activity.json` with 20,169 clock edges and nonzero
per-cycle toggles. The artifact verifier checked three input records and
returned `valid=true`. This establishes functional simulation and RTL activity
extraction for Ibex. It does not establish Ibex gate-level power: the
simple-system wrapper still lacks a verified mapped-netlist/OpenSTA path, and
the core-only netlist is not a drop-in replacement for that wrapper.

A five-sample calibration run (seed `20260901`) completed with every trial
above the 10,000-instruction useful-work floor. Its measured RTL activity
envelope was `75.47459106393761–76.16193221572304` total transitions per clock
edge. These bounds are suitable for activity-tier target normalization only;
they are not power-in-watts bounds and are not used as gate-level claims.

On 2026-09-03, a fresh ten-sample host calibration initially confirmed that
varying only instruction-stream length still produced a narrow
`75.5794185655843–75.9378289204592` envelope (0.47% span). The generator was
then changed to sample structured legal families (idle-heavy, ALU-heavy,
memory-heavy, and mixed). A fresh ten-sample calibration with that generator
passed the useful-work gate for every trial and widened the envelope to
`33.02092981603255–94.42136020261603` transitions per clock edge (186% span).
The latter is the calibration artifact to use for subsequent Ibex activity
experiments; the initial narrow result is retained as evidence of the prior
generator failure mode.

A fresh six-arm Ibex activity smoke (20 proposal slots per arm, seed `0`) then
completed with the widened calibration. All declared arms—random, mutation,
evolutionary, offline-agent, one-shot-agent, and offline-hybrid—completed their
isolated runs. The offline-agent history adapter bug found during this rerun
(the policy received `Trial` objects, not dictionaries) was fixed and covered
by the policy tests. This is a runner/integration validation artifact, not a
multi-seed statistical result.

Two additional Ibex seeds (`2`, `3`) were rerun at the same budget after fixing
the runner's policy-name serialization. The corrected summaries record
`offline-agent` and `offline-hybrid` explicitly; the earlier summaries using
the generic `agent`/`hybrid` labels are excluded from corrected inference.

The Ibex matrix entry point was smoke-tested in Docker with random, mutation,
and evolutionary policies at one proposal per policy using those bounds. All
three isolated runs produced one valid simulation with zero schema, protocol,
functional, or useful-work failures. This validates orchestration and artifact
separation only; it is not comparative performance evidence.

A three-proposal-per-policy Ibex pilot (seed `20260901`) then completed with
9/9 valid simulations across random, mutation, and evolutionary policies. The
activity-tier summaries are retained in the generated matrix format; this pilot
is intentionally too small for an inferential comparison and is not used as a
headline result.

A subsequent five-proposal-per-policy pilot with the same seed and calibrated
bounds completed 15/15 valid simulations across the same three policies. This
exercises history-dependent mutation and evolutionary proposals under a shared
budget; it remains activity-only and too small for an inferential claim.

The complete local Ibex arm set was also smoke-tested in Docker at one proposal
per arm: random, mutation, evolutionary, offline-agent, one-shot-agent, and
offline-hybrid. All 6/6 simulations were valid, with no schema, protocol,
functional, or useful-work failures. This confirms common-runner compatibility;
it is not comparative performance evidence.

An initial six-arm Ibex activity matrix (seed `0`, five proposal slots per arm)
completed with 30/30 valid simulations and zero failures at any validity stage.
The run used the calibrated activity bounds and shared proposal budget. It is a
preliminary activity-tier dataset; the sample is too small for inferential
policy claims and no gate-level power conclusion is drawn from it.

The first multi-seed Ibex activity dataset used seeds `1–3`, all six local arms,
and five proposal slots per arm. All 90/90 proposal slots completed valid
simulations. This confirms reproducible multi-seed orchestration and clean
validity accounting, but remains below the pre-registered 200-proposal budget
and is not a final policy comparison.

The first full-budget Ibex activity matrix used seed `0`, 200 proposal slots,
and all six local arms. All 1,200/1,200 proposal slots completed valid
simulations. The resulting activity-tier AUC summaries were random `2.9088`,
mutation `74.9344`, evolutionary `54.5826`, offline-agent `2.9088`,
one-shot-agent `11.7927`, and offline-hybrid `74.9344`; only random and
offline-agent reached the configured tolerance in this single seed. These are
descriptive activity-only results, not an inferential multi-seed comparison or
gate-level power claim.

Seed `1` of the full-budget Ibex matrix also completed with 1,200/1,200 valid
simulations. Its activity-tier AUC summaries were random `3.7176`, mutation
`15.3292`, evolutionary `3.0465`, offline-agent `3.7176`, one-shot-agent
`90.0793`, and offline-hybrid `15.3292`; random, evolutionary, and
offline-agent reached tolerance in this seed. These values remain descriptive
until the planned multi-seed aggregation is complete.

Seed `2` of the full-budget Ibex matrix completed with 1,200/1,200 valid
simulations. Its activity-tier AUC summaries were random `6.8117`, mutation
`35.1314`, evolutionary `22.4766`, offline-agent `6.8117`, one-shot-agent
`146.2547`, and offline-hybrid `35.1314`; random, evolutionary, and
offline-agent reached tolerance in this seed. These values remain descriptive
until the full seed set is aggregated.

Seed `3` of the full-budget Ibex matrix completed with 1,200/1,200 valid
simulations. Its activity-tier AUC summaries were random `4.2547`, mutation
`101.6232`, evolutionary `81.2774`, offline-agent `4.2547`, one-shot-agent
`77.3938`, and offline-hybrid `101.6232`; random and offline-agent reached
tolerance in this seed. These values remain descriptive until the full seed set
is aggregated. The run used an ephemeral container output root, so it is
recorded as audit evidence rather than a portable result archive.

Seed `4` of the full-budget Ibex matrix completed with 1,200/1,200 valid
simulations and persistent artifacts under `out/ibex-full/seed-4`. Its
activity-tier AUC summaries were random `1.8430`, mutation `2.7897`,
evolutionary `0.7075`, offline-agent `1.8430`, one-shot-agent `48.8044`, and
offline-hybrid `2.7897`; every policy except one-shot-agent reached tolerance
in this seed. This is still a single-seed descriptive result and activity-only;
the aggregation output has one run per arm and therefore is not an inferential
multi-seed comparison or a gate-level power claim.

Seed `0` was subsequently rerun with persistent output under
`out/ibex-full/seed-0` and completed with 1,200/1,200 valid simulations. The
activity-tier AUC summaries were random `2.9088`, mutation `74.9344`,
evolutionary `54.5826`, offline-agent `2.9088`, one-shot-agent `11.7927`, and
offline-hybrid `74.9344`; random and offline-agent reached tolerance. The
result is retained as a reproducible seed archive, but remains activity-only
and descriptive until the complete seed aggregation and gate-level validation.

Seed `1` was subsequently rerun with persistent output under
`out/ibex-full/seed-1` and completed with 1,200/1,200 valid simulations. Its
activity-tier AUC summaries were random `3.7176`, mutation `15.3292`,
evolutionary `3.0465`, offline-agent `3.7176`, one-shot-agent `90.0793`, and
offline-hybrid `15.3292`; random, evolutionary, and offline-agent reached
tolerance. The single-seed aggregate has no pairwise inferential comparisons;
this is reproducible activity-only evidence, not a gate-level power claim.

Seed `2` was subsequently rerun with persistent output under
`out/ibex-full/seed-2` and completed with 1,200/1,200 valid simulations. Its
activity-tier AUC summaries were random `6.8117`, mutation `35.1314`,
evolutionary `22.4766`, offline-agent `6.8117`, one-shot-agent `146.2547`, and
offline-hybrid `35.1314`; random, evolutionary, and offline-agent reached
tolerance. The persistent seed archive is reproducible activity-only evidence;
it does not establish a gate-level power claim.

Seed `3` completed with persistent output under `out/ibex-full/seed-3` and
1,200/1,200 valid simulations. Its activity-tier AUC summaries were random
`4.2547`, mutation `101.6232`, evolutionary `81.2774`, offline-agent `4.2547`,
one-shot-agent `77.3938`, and offline-hybrid `101.6232`; random and
offline-agent reached tolerance. The persistent seed archive is reproducible
activity-only evidence; it does not establish a gate-level power claim.

The complete persistent Ibex activity archive now covers seeds `0` through `4`,
with 1,000 valid simulations per policy and zero failures at all validity
stages. The five-seed aggregate and paired inference are stored at
`out/ibex-full/seeds-0-1-2-3-4-aggregate.json` and
`out/ibex-full/seeds-0-1-2-3-4-inference.json`. Mean AUC was random and
offline-agent `3.9072`, evolutionary `32.4181`, mutation and offline-hybrid
`45.9616`, and one-shot-agent `74.8650`; solve rates were respectively `1.00`,
`1.00`, `0.60`, `0.20`, `0.20`, and `0.00`. The paired activity-tier audit
found no Holm-adjusted significant difference at this sample size (minimum
adjusted p-value `0.3125`). These results remain descriptive activity-only
evidence because the Ibex wrapper lacks gate-level OpenSTA support.

The memory inventory and collateral path was validated on the current pinned
RTL closures. AES `aes_cipher_core` produced zero inferred memories. AXI DMA
produced 13 internal 32-entry FIFO memories with independent read and write
ports; the pinned BSG FakeRAM backend is single-port synchronous 1RW, so Yosys
rejects that mapping and the baseline remains unchanged. Ibex core inventory
produced four memories and two unique read-only geometries (32×32 and 16×3),
but their read ports are asynchronous (`RD_CLK_ENABLE=0`), which is also
incompatible with BSG FakeRAM's synchronous interface.

The integrated AES acceptance smoke was rerun after the five-seed Ibex update
with `make research-smoke`. It passed with synthesis-backed scalar evaluation,
determinism checking, activity extraction/plotting, and temporal and
compositional profile searches. The resulting bundle is under
`out/research-smoke/`; this is an integration checkpoint, not additional
comparative evidence.

BSG generation was run in an isolated checkout for the AXI and Ibex physical
geometries. CACTI-required padding is recorded explicitly as physical geometry
in the generated manifest; logical widths and depths are never silently
replaced. Generated collateral is reproducible diagnostic evidence, not a
claim that either design has been successfully macro-mapped.

Offline agent and hybrid summaries are tagged `heuristic_smoke_only` and are
excluded from policy inference. Only the Vertex-backed arm is eligible for the
cross-design agent claim.
### Vertex semantic-context smoke

The first DMA Vertex smoke exposed a response-envelope issue rather than a
search failure: Gemini returned a singleton workload object instead of a list.
The parser now accepts the documented singleton and hypothesis-plus-workloads
forms while preserving strict candidate validation. A one-slot DMA smoke then
produced a valid workload and completed the coupled activity evaluator on
2026-09-04. The run used `gemini-2.5-flash`, 494 input tokens, 242 output
tokens, and an estimated $0.0007532 at the configured standard text rates.

### Temporal DSL gate (2026-09-04)

The 48-block sustained, burst, alternating, and ramp workloads produce
distinct eight-bin activity vectors. Burst stays near-flat; alternating
schedules preserve alternating peaks; ramp declines as gaps increase. The
temporal target arm therefore remains in scope. The 8-block probe was rejected
by the existing 38-block useful-work floor and was not scored.

Batch calibration showed that retries are material: an eight-slot DMA call
produced 4/8 valid proposals, 4 schema failures, 118,054 input tokens, and
$0.03975 estimated spend. AES produced 6/8 valid proposals at $0.00219. Ibex
produced no valid proposals because its short programs failed the useful-work
floor; its runner now records those failures and bounds nonterminating
simulations with a wall-clock guard.

### Vertex scalar pilot (2026-09-04)

The first three-seed pilot launched all three real Vertex arms. AES completed
20 proposals per seed with 4, 7, and 17 valid trials; estimated spend was
$0.3616 total. DMA completed 8 proposals per seed with 0, 0, and 4 valid
trials; Ibex completed 8 per seed with no valid trials. DMA and Ibex results
are diagnostic only: strict batch parsing and useful-work compliance remain
too weak for comparative claims. The pilot exposed this before the factorial
matrix and consumed approximately $0.38 including calibration.

The local 10-seed, 50-proposal matrix directory is not tracked and is not
reported as a result until its summaries are deliberately archived and
reviewed. The finalized AES scalar calibration uses epsilon 0.02 after the
required recheck on the widened corpus (random target coverage r=0.2).

## 2026-09-05 — Complete AES semantic development comparison

New transaction-backend evidence is archived in
`results/aes_transactions_development/`, with the matched edit control in
`results/aes_transactions_development_matched/`. The combined comparison
contains six policies × five targets × three development seeds, 50 proposal
slots each. All 4,500 slots passed the independent ledger audit.

Primary endpoint, mean best-so-far AUC (lower is better): semantic-edits-v4
1.6073; matched scalar-edit-evolution 1.7473; random 2.1849;
instrumented coverage-guided-line 2.8559; evolutionary 4.5760; mutation
4.8863. Semantic and matched-edit policies each solved 14/15 runs; random
solved 12/15. The semantic arm used an estimated $0.5549 including recorded
thinking tokens. Invalid proposals remain charged and included.

This is a descriptive **development** result: approximately 26.4% lower
agent AUC than random and 8.0% lower than the matched edit control. There
is no confirmatory superiority or parity claim. DMA development and the
held-out study are unfinished; the catalog-interface candidate is queued
for separate development evaluation. The endpoint is DUT-scoped RTL
activity, not validated dynamic power, and scalar edits do not establish
structural, temporal or compositional expressiveness.

These data use the new transaction harness and fresh calibration archived
with them. Do not pool them with legacy harness/calibration results above.
Early development cells lack the later full source-hash run manifest;
that limitation is recorded in the archive README. The historical warning
above about unarchived results predates the current tracked result archives.

## 2026-09-05 — Matched-window temporal capability on transaction AES

`results/aes_transactions_temporal_check.json` records five hand-written
schedules, each performing 64 reference-checked AES blocks and 6000 idle
cycles. All run for exactly 6774 clock edges; two repeats are identical.
Their mean DUT activity is almost unchanged (23.3417–23.3500 transitions
per edge), while eight equal-clock-bin rates separate markedly:

- Uniform pacing: approximately 23.3 throughout.
- Burst then idle: 172.9 in the first bin, then 2.0 throughout.
- Low–high–low: approximately 2.0 outside the middle bins, 86.4 and 88.3 inside.
- Alternating: approximately 44.7, 2.0, repeated four times.
- Ramp-like: uneven, with late bins 53.3 and 60.7; not a monotonic ramp.

This is evidence of temporal control at matched work, duration and nearly
matched scalar activity. It is not an agent comparison, a gate-power result,
or proof that any policy can reproduce held-out temporal profiles. It makes
the distinction between scalar targeting and temporal expressiveness concrete.

## 2026-09-05 — Complete DMA baseline development panel

`results/dma_pipelined_development_baselines/` contains all 60 cells and
3,000 audited proposal slots. Mean AUC: random 2.0764, evolutionary 4.3431,
matched scalar-edit-evolution 5.2186, mutation 5.6657. Random and evolutionary
each solve 9/15 runs, mutation 6/15, matched scalar edits 3/15.

The matched scalar-edit control has only 21.9% valid proposals. It isolates
the edit representation but is not a strong legal optimizer; improvements
over it alone would confound search quality with protocol compliance.
Random is the strongest observed baseline in this development panel.
The DMA agent and catalog-interface panels are still incomplete, so there
is no full cross-design agent comparison yet. The archive records the
serial-to-four-worker scheduling change and prohibits a pooled runtime claim.

## 2026-09-05 — Complete semantic v4 cross-design development evidence

The DMA agent panel is now complete: 15 runs, 750 audited proposal slots,
archived in `results/dma_pipelined_development_agent/`. Mean AUC is 2.5116,
about 21.0% worse than random's 2.0764. The agent solves 12/15 versus
random's 9/15, but this secondary metric does not overturn the primary AUC
finding. Agent validity is 79.2%; recorded estimated cost is $0.7667 with
two calls of unknown usage, so the cost accounting is incomplete.

V4 improves development AUC against random on AES, but worsens it on DMA.
This does not establish cross-design superiority. The catalog-interface v5
candidate is now running on AES and then DMA with the same controller.
Selection will follow the predeclared balanced development-AUC rule in
`HELD_OUT_PROTOCOL.md`; held-out seeds remain unused.

## 2026-09-05 — Complete AES catalog-controller development panel

`results/aes_catalog_development/` contains all 15 V5 cells and 750 audited
proposal slots. Mean AUC is 1.2604, compared with V4's 1.6073, random's
2.1849 and instrumented line-coverage search's 2.8559 under the same
calibration, targets, seeds and budget. V5 solves 14/15; validity is 93.1%.
Recorded estimated cost is $0.6743, excluding unknown usage from two calls.

This is an AES development improvement, not a held-out or cross-design claim.
DMA V5 is running; the predeclared selection still requires both complete
design panels. No evaluation seeds have been used.

## 2026-09-05 — Complete V5 development and cross-design selection

DMA V5 completed all 15 cells and 750 audited slots, archived in
`results/dma_catalog_development/`. Mean AUC is 5.0036 versus random's
2.0764 and V4's 2.5116; V5 solves 4/15 with 67.5% validity. Recorded
estimated cost is $1.1229, with five unknown-usage batches. The catalog
interface's AES improvement did not transfer to DMA.

The predeclared balanced selection chooses **semantic-edits-v4**: mean AUC
across both designs is 2.0595 versus V5's 3.1320. All 30 cells per candidate
were included. `results/semantic_controller_selection.json` records the
selection and source panels. No per-design controller selection or further
prompt tuning is permitted for this held-out evaluation. Selection itself
is not evidence of held-out superiority.

## 2026-09-05 — Complete held-out semantic study

All 550 evaluation cells and 27,500 slots are complete, independently audited
and archived. The full primary AUC table, nine corrected comparisons, validity
and cost accounting are in [SEMANTIC_RESULTS.md](SEMANTIC_RESULTS.md), backed
by `results/semantic_heldout_comparison.json` and the four held-out panels.
Every cell matches the recorded source/configuration freeze.

AES agent mean AUC is 2.1938 versus random 2.2393; DMA agent AUC is 2.6507
versus random 2.0849. Parity with random is not established. Only the DMA
mutation and matched scalar-edit comparisons support agent superiority after
the predeclared Holm correction. Higher AES solve rate is secondary and does
not replace the AUC result. Eight batches have unknown provider usage; the
$4.3444 recorded agent estimate is incomplete cost accounting.

Earlier dated statements that development or held-out panels are still running
are historical checkpoints, superseded by this entry. Scalar activity results
do not establish power prediction or structural/temporal expressiveness.

## 2026-09-07 — Programmable CPU temporal development and allocation diagnostic

The separate [v1 CPU pilot](IBEX_EXPRESSIVENESS_RESULTS.md) completed 36 cells
and 576 slots. Agent model-generated validity was 37.5%; work-count arithmetic
rejected 95 slots. Random had lower mean AUC. Those results remain unchanged.

The frozen [v2 allocation diagnostic](IBEX_PROPOSAL_V2_RESULTS.md) also completed
all 36 cells and 576 slots. A shared exact-work allocator raises model-generated
validity to 157/168 (93.45%), with zero work-count or architectural failures.
All 192 random control slots reproduce v1 measurements exactly. Agent mean AUC
is 4.554168 versus random 4.831839 and mutation 5.126319; agent and random both
solve 3/12 cells. This is encouraging development evidence, not held-out
superiority, intrinsic expressiveness or gate-power evidence. The hard temporal
targets remain unsolved. Full compact records are tracked under
`results/ibex_proposal_v2_development/`.
