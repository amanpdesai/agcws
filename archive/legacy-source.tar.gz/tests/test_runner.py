from agcws.adapters.aes import AESAdapter
from agcws.experiments.runner import run_search
from agcws.goals import ScalarGoal
from agcws.nodes.power import PowerProfile
from agcws.policies.random_search import RandomSearch
from agcws.policies.agent import AgentPolicy


def test_runner_counts_requested_slots_and_writes_curve(tmp_path):
    def evaluate(workload):
        return PowerProfile(5.0, 5.0, useful_work=16, valid=True)

    trials = run_search(AESAdapter(), RandomSearch(3), ScalarGoal(0.5), evaluate,
                        budget=5, batch_size=8, p_min=1, p_max=9, output_dir=tmp_path)
    assert len(trials) == 5
    assert len(__import__("json").loads((tmp_path / "best_so_far.json").read_text())["error"]) == 5
    summary = __import__("json").loads((tmp_path / "summary.json").read_text())
    assert "validity_failures" in summary
    assert "tokens_in" in summary
    assert summary["budget"] == 5
    assert summary["proposals"] == 5
    assert summary["proposal_slots"] == 5
    assert summary["policy"] == "random"
    assert summary["design"] == AESAdapter.name
    assert summary["seed"] == 0
    assert summary["target"] == 0.5
    assert "auc_best_so_far" in summary


def test_runner_applies_runtime_useful_work_gate():
    def evaluate(workload):
        return PowerProfile(5.0, 5.0, useful_work=1, valid=True)

    trials = run_search(AESAdapter(), RandomSearch(3), ScalarGoal(0.5), evaluate,
                        budget=1, p_min=1, p_max=9)
    assert not trials[0].validity.valid
    assert trials[0].validity.stage.value == "USEFUL_WORK"
    assert trials[0].profile is not None
    assert trials[0].loss is None
    assert trials[0].sim_count == 1
    assert trials[0].evaluation_attempts == 1


def test_runner_records_malformed_batch_as_consumed_schema_slots():
    policy = AgentPolicy(lambda *_: (_ for _ in ()).throw(ValueError("bad JSON")))
    calls = []

    def evaluate(workload):
        calls.append(workload)
        return PowerProfile(1.0, 1.0, useful_work=24, valid=True)

    trials = run_search(AESAdapter(), policy, ScalarGoal(0.5), evaluate,
                        budget=3, batch_size=3, p_min=0.0, p_max=2.0)
    assert len(trials) == 3
    assert not calls
    assert all(trial.validity.stage.value == "SCHEMA" for trial in trials)
    assert all(trial.evaluation_attempts == trial.sim_count == 0 for trial in trials)


def test_runner_distinguishes_evaluator_attempt_from_known_completion():
    def evaluate(workload):
        raise RuntimeError('reference check failed')

    trials = run_search(AESAdapter(), RandomSearch(3), ScalarGoal(0.5), evaluate,
                        budget=1, p_min=1, p_max=9)
    trial = trials[0]
    assert trial.evaluation_attempts == 1
    assert trial.sim_count == 0
    assert trial.loss is None
    assert trial.evaluation_diagnostics == {'exception_type': 'RuntimeError',
                                          'message': 'reference check failed',
                                          'simulation_completion_unknown': True}


def test_runner_records_non_list_policy_response_as_schema_slots():
    class BadPolicy:
        name = "bad"

        def propose(self, *_args):
            return {"not": "a batch"}

    trials = run_search(AESAdapter(), BadPolicy(), ScalarGoal(0.5),
                        lambda _: PowerProfile(1.0, 1.0, useful_work=24, valid=True),
                        budget=2, batch_size=2, p_min=0.0, p_max=2.0)
    assert len(trials) == 2
    assert all(not trial.validity.valid for trial in trials)
    assert all(trial.validity.stage.value == "SCHEMA" for trial in trials)


def test_runner_records_non_dict_candidate_as_schema_failure():
    class BadPolicy:
        name = "bad"

        def propose(self, *_args):
            return ["not a workload"]

    trials = run_search(AESAdapter(), BadPolicy(), ScalarGoal(0.5),
                        lambda _: PowerProfile(1.0, 1.0, useful_work=24, valid=True),
                        budget=1, batch_size=1, p_min=0.0, p_max=2.0)
    assert trials[0].validity.stage.value == "SCHEMA"
