"""Budget-fair search runner independent of any particular evaluator backend."""
from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Callable

from agcws.adapters.base import DesignAdapter, SimResult, Validity, ValidityStage
from agcws.analysis.metrics import summarize_run
from agcws.goals.loss import loss
from agcws.nodes.power import PowerProfile
from agcws.nodes.validation import validate_static
from agcws.policies.base import SearchPolicy
from agcws.telemetry.ledger import Trial
from agcws.experiments.provenance import capture_run


def _vertex_cost(tokens_in: int, tokens_out: int, model: str) -> float:
    """Estimate Vertex text cost from explicit per-million-token settings."""
    if not model:
        return 0.0
    prefix = "AGCWS_GEMINI_"
    input_rate = os.getenv(prefix + "INPUT_USD_PER_MILLION")
    output_rate = os.getenv(prefix + "OUTPUT_USD_PER_MILLION")
    if input_rate is None or output_rate is None:
        return 0.0
    try:
        return (tokens_in * float(input_rate) + tokens_out * float(output_rate)) / 1_000_000
    except ValueError:
        return 0.0


def _jsonable(value):
    if is_dataclass(value):
        return _jsonable(asdict(value))
    if hasattr(value, "value"):
        return value.value
    if isinstance(value, dict):
        return {key: _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    return value


def run_search(
    adapter: DesignAdapter,
    policy: SearchPolicy,
    goal,
    evaluate: Callable[[dict], PowerProfile],
    *,
    budget: int = 200,
    batch_size: int = 8,
    seed: int = 0,
    design: str | None = None,
    p_min: float | None = None,
    p_max: float | None = None,
    output_dir: Path | None = None,
) -> list[Trial]:
    """Run exactly ``budget`` proposal slots, including invalid candidates."""
    if budget <= 0 or batch_size <= 0:
        raise ValueError("budget and batch_size must be positive")
    if output_dir is not None:
        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / 'run_manifest.json').write_text(json.dumps(
            capture_run(adapter, policy, goal, budget, batch_size, seed, p_min, p_max),
            sort_keys=True, indent=2) + '\n')
    trials: list[Trial] = []
    best = float("inf")
    curve: list[float] = []
    proposal_index = 0
    while proposal_index < budget:
        requested = min(batch_size, budget - proposal_index)
        generation_started = time.monotonic()
        try:
            candidates = policy.propose(adapter, goal, trials, requested)
        except (TypeError, ValueError):
            candidates = []
        if not isinstance(candidates, (list, tuple)):
            candidates = []
        generation_elapsed = time.monotonic() - generation_started
        usage = getattr(policy, "last_usage", {})
        for slot in range(requested):
            workload = candidates[slot] if slot < len(candidates) else {}
            if not isinstance(workload, dict):
                workload = {"__malformed_candidate__": workload}
            started = time.monotonic()
            validity = validate_static(adapter, workload)
            profile = None
            sim_count = 0
            evaluation_attempts = 0
            evaluation_diagnostics = {}
            if validity.valid:
                evaluation_attempts = 1
                try:
                    profile = evaluate(workload)
                except (RuntimeError, ValueError, OSError) as exc:
                    evaluation_diagnostics = {'exception_type': type(exc).__name__,
                                              'message': str(exc), 'simulation_completion_unknown': True}
                    validity = Validity(False, ValidityStage.FUNCTIONAL,
                                        "evaluator rejected workload")
                else:
                    sim_count = 1
                    if not profile.valid:
                        validity = adapter.validate_result(
                            SimResult(False, True, False, profile.useful_work)
                        )
                    else:
                        validity = adapter.validate_result(
                            SimResult(True, True, True, profile.useful_work)
                        )
            if validity.valid and profile is not None:
                current = loss(profile, goal, p_min=p_min, p_max=p_max)
                best = min(best, current)
            else:
                current = float("inf")
            curve.append(best)
            trials.append(Trial(
                trial_id=f"{policy.name}-{proposal_index + slot:05d}",
                design=design or adapter.name,
                goal=goal,
                policy=policy.name,
                seed=seed,
                workload=workload,
                validity=validity,
                profile=profile,
                loss=None if not validity.valid else current,
                wall_clock_s=time.monotonic() - started,
                generation_wall_clock_s=generation_elapsed if slot == 0 else 0.0,
                generation_diagnostics=getattr(policy, "last_diagnostics", {}) if slot == 0 else {},
                sim_count=sim_count,
                evaluation_attempts=evaluation_attempts,
                evaluation_diagnostics=evaluation_diagnostics,
                model=getattr(policy, "model", ""),
                prompt_hash=getattr(policy, "prompt_hash", ""),
                claim_scope=getattr(policy, "claim_scope", "baseline"),
                tokens_in=int(usage.get("tokens_in", 0)) if slot == 0 else 0,
                tokens_out=int(usage.get("tokens_out", 0)) if slot == 0 else 0,
                est_cost_usd=_vertex_cost(
                    int(usage.get("tokens_in", 0)) if slot == 0 else 0,
                    int(usage.get("tokens_out", 0)) if slot == 0 else 0,
                    getattr(policy, "model", ""),
                ),
            ))
        proposal_index += requested
    if output_dir is not None:
        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / "trials.jsonl").write_text("\n".join(
            json.dumps({k: _jsonable(v) for k, v in asdict(trial).items()}, sort_keys=True)
            for trial in trials
        ) + "\n")
        (output_dir / "best_so_far.json").write_text(json.dumps({"error": curve}) + "\n")
        summary = summarize_run(curve, goal.tolerance, budget=budget)
        stages = {stage.value: 0 for stage in ValidityStage}
        for trial in trials:
            if not trial.validity.valid and trial.validity.stage is not None:
                stages[trial.validity.stage.value] += 1
        summary.update({"policy": policy.name, "design": design or adapter.name,
                        "seed": seed, "validity_failures": stages,
                        "epsilon": float(goal.tolerance),
                        "proposals": len(trials),
                        "proposal_slots": budget,
                        "valid_trials": sum(trial.validity.valid for trial in trials),
                        "claim_scope": getattr(policy, "claim_scope", "baseline"),
                        "tokens_in": sum(trial.tokens_in for trial in trials),
                        "tokens_out": sum(trial.tokens_out for trial in trials),
                        "est_cost_usd": sum(trial.est_cost_usd for trial in trials),
                        "unknown_usage_batches": sum(bool(trial.generation_diagnostics.get('usage_unknown'))
                                                     for trial in trials),
                        "simulations": sum(trial.sim_count for trial in trials),
                        "simulation_count_semantics": "evaluator_returned_profile_including_invalid_workloads",
                        "evaluation_attempts": sum(trial.evaluation_attempts for trial in trials),
                        "unknown_simulation_completions": sum(bool(trial.evaluation_diagnostics.get('simulation_completion_unknown'))
                                                              for trial in trials)})
        if hasattr(goal, "q"):
            summary["target"] = float(goal.q)
        else:
            summary["target"] = "profile"
        (output_dir / "summary.json").write_text(
            json.dumps(summary, indent=2, sort_keys=True) + "\n"
        )
    return trials
