# Overleaf project

Upload this ZIP using New Project > Upload Project.
Set the main document to main.tex and the compiler to pdfLaTeX.
IEEEtran and the standard LaTeX packages are supplied by Overleaf.
Click Recompile. No Python, simulation tools, shell escape, or result archives
are required. References are in references.bib, formatted with IEEEtran BibTeX.

Edit main.tex directly. The figures are static PDFs with repository-verified
measurement inputs; do not edit their numbers by hand.
Check author details before submission.

The manuscript uses the official IEEE conference template:
https://www.overleaf.com/latex/templates/ieee-conference-template/grfzhhncsfqn

The canonical repository source is paper/report.tex, renamed main.tex only in
this upload bundle. SOURCE_MANIFEST.json records the packaged file hashes.
To regenerate figures, use the repository's paper/scripts/build.py, then overleaf.py.
After editing in Overleaf, download the source and bring main.tex back as
paper/report.tex before regenerating this bundle. Do not maintain two diverging
manuscripts. The four-page hackathon limit includes references and figures.

WARNING: This working draft is 5 pages, exceeding the four-page submission limit. Shorten it before submission.
